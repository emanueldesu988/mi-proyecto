/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.poo.servicio;

import org.poo.vista.genero.*;
import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.ClienteDto;
import org.poo.modelo.Cliente;
import org.poo.recurso.constante.Persistencia;

public class ClienteServicio implements ApiOperacionBD<ClienteDto, Integer> {
    private NioFile miArchivo;

    public ClienteServicio() {
        try {
            miArchivo = new NioFile(Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                                   "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Cliente.txt");
        } catch (IOException ex) {
            Logger.getLogger(ClienteServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        int id = 0;
        try {
            id = miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(ClienteServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    @Override
    public ClienteDto insertInto(ClienteDto dto, String ruta) {
        Cliente obj = new Cliente();
        obj.setIdCliente(getSerial());
        obj.setNombreCliente(dto.getNombreCliente());
        obj.setApellidoCliente(dto.getApellidoCliente());
        obj.setDocumentoCliente(dto.getDocumentoCliente());
        obj.setTelefonoCliente(dto.getTelefonoCliente());
        obj.setEmailCliente(dto.getEmailCliente());

        String fila = obj.getIdCliente() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreCliente() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getApellidoCliente() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getDocumentoCliente() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getTelefonoCliente() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getEmailCliente() + Persistencia.SEPARADOR_COLUMNAS + "0";

        if (miArchivo.agregarRegistro(fila)) {
            dto.setIdCliente(obj.getIdCliente());
            return dto;
        }
        return null;
    }

    @Override
    public List<ClienteDto> selectFrom() {
        List<ClienteDto> arreglo = new ArrayList<>();
        List<String> datos = miArchivo.obtenerDatos();

        for (String cadena : datos) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                ClienteDto dto = new ClienteDto(
                    Integer.parseInt(cols[0].trim()),
                    cols[1].trim(), cols[2].trim(), cols[3].trim(),
                    cols[4].trim(), cols[5].trim(), Short.parseShort(cols[6].trim())
                );
                arreglo.add(dto);
            } catch (Exception ex) {
                Logger.getLogger(ClienteServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public List<ClienteDto> selectFromWhereActivos() {
        return selectFrom();
    }

    @Override
    public int numRows() {
        try {
            return miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(ClienteServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        try {
            return !miArchivo.borrarFilaPosicion(codigo).isEmpty();
        } catch (IOException ex) {
            Logger.getLogger(ClienteServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public ClienteDto updateSet(Integer codigo, ClienteDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ClienteDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
