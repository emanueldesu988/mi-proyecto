package org.poo.servicio;

import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.DistribuidoraDto;
import org.poo.modelo.Distribuidora;
import org.poo.recurso.constante.Persistencia;
import org.poo.recurso.utilidad.GestorImagen;

public class DistribuidoraServicio implements ApiOperacionBD<DistribuidoraDto, Integer> {
    private NioFile miArchivo;
    private String nombrePersistencia;

    public DistribuidoraServicio() {
        nombrePersistencia = Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                            "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Distribuidora.txt";
        try {
            miArchivo = new NioFile(nombrePersistencia);
        } catch (IOException ex) {
            Logger.getLogger(DistribuidoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        try {
            return miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(DistribuidoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public DistribuidoraDto insertInto(DistribuidoraDto dto, String ruta) {
        Distribuidora obj = new Distribuidora();
        obj.setIdDistribuidora(getSerial());
        obj.setNombreDistribuidora(dto.getNombreDistribuidora());
        obj.setPaisDistribuidora(dto.getPaisDistribuidora());
        obj.setEstadoDistribuidora(dto.getEstadoDistribuidora());
        obj.setCantidadPeliculasDistribuidora((short) 0);
        obj.setNombreImagenPublicoDistribuidora(dto.getNombreImagenPublicoDistribuidora());
        obj.setNombreImagenPrivadoDistribuidora(GestorImagen.grabarLaImagen(ruta));

        String fila = obj.getIdDistribuidora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreDistribuidora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getPaisDistribuidora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getEstadoDistribuidora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getCantidadPeliculasDistribuidora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreImagenPublicoDistribuidora() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreImagenPrivadoDistribuidora();

        if (miArchivo.agregarRegistro(fila)) {
            dto.setIdDistribuidora(obj.getIdDistribuidora());
            return dto;
        }
        return null;
    }

    @Override
    public List<DistribuidoraDto> selectFrom() {
        List<DistribuidoraDto> arreglo = new ArrayList<>();
        List<String> datos = miArchivo.obtenerDatos();

        for (String cadena : datos) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                if (cols.length >= 7) {
                    DistribuidoraDto dto = new DistribuidoraDto(
                        Integer.parseInt(cols[0].trim()),
                        cols[1].trim(), cols[2].trim(), Boolean.valueOf(cols[3].trim()),
                        Short.parseShort(cols[4].trim()), cols[5].trim(), cols[6].trim()
                    );
                    arreglo.add(dto);
                }
            } catch (Exception ex) {
                Logger.getLogger(DistribuidoraServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public List<DistribuidoraDto> selectFromWhereActivos() {
        List<DistribuidoraDto> arreglo = new ArrayList<>();
        List<String> datos = miArchivo.obtenerDatos();

        for (String cadena : datos) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                if (cols.length >= 7) {
                    Boolean estado = Boolean.valueOf(cols[3].trim());
                    if (estado) {
                        DistribuidoraDto dto = new DistribuidoraDto(
                            Integer.parseInt(cols[0].trim()),
                            cols[1].trim(), cols[2].trim(), estado,
                            Short.parseShort(cols[4].trim()), cols[5].trim(), cols[6].trim()
                        );
                        arreglo.add(dto);
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(DistribuidoraServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public int numRows() {
        try {
            return miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(DistribuidoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        try {
            return !miArchivo.borrarFilaPosicion(codigo).isEmpty();
        } catch (IOException ex) {
            Logger.getLogger(DistribuidoraServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public DistribuidoraDto updateSet(Integer codigo, DistribuidoraDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public DistribuidoraDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
