/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.poo.servicio;

import org.poo.vista.genero.*;
import com.poo.persistence.NioFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.poo.api.ApiOperacionBD;
import org.poo.dto.DirectorDto;
import org.poo.modelo.DIrector;
import org.poo.recurso.constante.Persistencia;
import org.poo.recurso.utilidad.GestorImagen;

public class DirectorServicio implements ApiOperacionBD<DirectorDto, Integer> {
    private NioFile miArchivo;

    public DirectorServicio() {
        try {
            miArchivo = new NioFile(Persistencia.RUTA_PROYECTO + Persistencia.SEPARADOR_CARPETAS + 
                                   "miBaseDeDatos" + Persistencia.SEPARADOR_CARPETAS + "Director.txt");
        } catch (IOException ex) {
            Logger.getLogger(DirectorServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getSerial() {
        try {
            return miArchivo.ultimoCodigo() + 1;
        } catch (IOException ex) {
            Logger.getLogger(DirectorServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public DirectorDto insertInto(DirectorDto dto, String ruta) {
        DIrector obj = new DIrector();
        obj.setIdDirector(getSerial());
        obj.setNombreDirector(dto.getNombreDirector());
        obj.setNacionalidadDirector(dto.getNacionalidadDirector());
        obj.setNombreImagenPublicoDirector(dto.getNombreImagenPublicoDirector());
        obj.setNombreImagenPrivadoDirector(GestorImagen.grabarLaImagen(ruta));

        String fila = obj.getIdDirector() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreDirector() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNacionalidadDirector() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreImagenPublicoDirector() + Persistencia.SEPARADOR_COLUMNAS
                + obj.getNombreImagenPrivadoDirector();

        if (miArchivo.agregarRegistro(fila)) {
            dto.setIdDirector(obj.getIdDirector());
            return dto;
        }
        return null;
    }

    @Override
    public List<DirectorDto> selectFrom() {
        List<DirectorDto> arreglo = new ArrayList<>();
        for (String cadena : miArchivo.obtenerDatos()) {
            try {
                String[] cols = cadena.replace("@", "").split(Persistencia.SEPARADOR_COLUMNAS);
                DirectorDto dto = new DirectorDto(
                    Integer.parseInt(cols[0].trim()),
                    cols[1].trim(), cols[2].trim(), (short)0,
                    cols.length > 3 ? cols[3].trim() : "",
                    cols.length > 4 ? cols[4].trim() : ""
                );
                arreglo.add(dto);
            } catch (Exception ex) {
                Logger.getLogger(DirectorServicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return arreglo;
    }

    @Override
    public List<DirectorDto> selectFromWhereActivos() {
        return selectFrom();
    }

    @Override
    public int numRows() {
        try {
            return miArchivo.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(DirectorServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public Boolean deleteFrom(Integer codigo) {
        try {
            return !miArchivo.borrarFilaPosicion(codigo).isEmpty();
        } catch (IOException ex) {
            Logger.getLogger(DirectorServicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public DirectorDto updateSet(Integer codigo, DirectorDto objeto, String ruta) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public DirectorDto getOne(Integer codigo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
