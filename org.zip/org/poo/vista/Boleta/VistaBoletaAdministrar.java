package org.poo.vista.boleta;

import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.poo.controlador.boleta.BoletaControladorEliminar;
import org.poo.controlador.boleta.BoletaControladorListar;
import org.poo.dto.BoletaDto;
import org.poo.recurso.constante.Configuracion;
import org.poo.recurso.utilidad.Icono;
import org.poo.recurso.utilidad.Marco;
import org.poo.recurso.utilidad.Mensaje;

public class VistaBloetaAdministrar extends StackPane {
    private final Rectangle marco;
    private final Stage miEscenario;
    private final VBox cajaVertical;
    private final TableView<BoletaDto> miTabla;

    private static final String ESTILO_CENTRAR = "-fx-alignment: CENTER;";
    private static final String ESTILO_IZQUIERDA = "-fx-alignment: CENTER-LEFT;";
    private static final String ESTILO_ROJO = "-fx-text-fill: red;" + ESTILO_CENTRAR;
    private static final String ESTILO_VERDE = "-fx-text-fill: green;" + ESTILO_CENTRAR;

    private Text titulo;
    private HBox cajaBotones;

    public VistaBloetaAdministrar(Stage ventanaPadre, double ancho, double alto) {
        setAlignment(Pos.CENTER);
        miEscenario = ventanaPadre;
        marco = Marco.crear(miEscenario,
                Configuracion.MARCO_ALTO_PORCENTAJE,
                Configuracion.MARCO_ANCHO_PORCENTAJE,
                Configuracion.DEGRADE_ARREGLO_PELICULA,
                Configuracion.DEGRADE_BORDE
        );

        miTabla = new TableView<>();
        cajaVertical = new VBox(20);
        getChildren().add(marco);

        configurarCajaVertical();
        crearTitulo();
        crearTabla();
        losIconosAdmin();
    }

    private void configurarCajaVertical() {
        cajaVertical.setAlignment(Pos.TOP_CENTER);
        cajaVertical.prefWidthProperty().bind(miEscenario.widthProperty());
        cajaVertical.prefHeightProperty().bind(miEscenario.heightProperty());
    }

    private void crearTitulo() {
        Region bloqueSeparador = new Region();
        bloqueSeparador.prefHeightProperty().bind(
                miEscenario.heightProperty().multiply(0.05));

        int cant = BoletaControladorListar.obtenerCantidadBoletas();
        titulo = new Text("ADMINISTRAR BOLETAS (" + cant + ")");
        titulo.setFill(Color.web(Configuracion.MORADO_OSCURO));
        titulo.setFont(Font.font("Rockwell", FontWeight.BOLD, 28));

        cajaVertical.getChildren().addAll(bloqueSeparador, titulo);
    }

    private void crearTabla() {
        TableColumn<BoletaDto, Integer> colCodigo = new TableColumn<>("Código");
        colCodigo.setCellValueFactory(new PropertyValueFactory<>("idBoleta"));
        colCodigo.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.15));
        colCodigo.setStyle(ESTILO_CENTRAR);

        TableColumn<BoletaDto, String> colAsiento = new TableColumn<>("Asiento");
        colAsiento.setCellValueFactory(new PropertyValueFactory<>("numeroAsientoBoleta"));
        colAsiento.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.25));
        colAsiento.setStyle(ESTILO_IZQUIERDA);

        TableColumn<BoletaDto, String> colFecha = new TableColumn<>("Fecha");
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaCompraBoleta"));
        colFecha.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.30));
        colFecha.setStyle(ESTILO_CENTRAR);

        TableColumn<BoletaDto, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(obj -> {
            String estado = obj.getValue().getEstadoBoleta() ? "Activa" : "Inactiva";
            return new SimpleStringProperty(estado);
        });
        colEstado.setCellFactory(col -> new TableCell<BoletaDto, String>() {
            @Override
            protected void updateItem(String text, boolean empty) {
                super.updateItem(text, empty);
                if (empty || text == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(text);
                    setStyle("Activa".equals(text) ? ESTILO_VERDE : ESTILO_ROJO);
                }
            }
        });
        colEstado.prefWidthProperty().bind(miTabla.widthProperty().multiply(0.30));

        miTabla.getColumns().addAll(colCodigo, colAsiento, colFecha, colEstado);

        List<BoletaDto> datos = BoletaControladorListar.obtenerBoletas();
        ObservableList<BoletaDto> datosTabla = FXCollections.observableArrayList(datos);
        miTabla.setItems(datosTabla);
        miTabla.setPlaceholder(new Text("No hay Boletas Registradas."));
        miTabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

        miTabla.maxWidthProperty().bind(miEscenario.widthProperty().multiply(0.70));
        miTabla.maxHeightProperty().bind(miEscenario.heightProperty().multiply(0.50));

        miEscenario.heightProperty().addListener((o, oldVal, newVal) -> miTabla.setPrefHeight(newVal.doubleValue()));
        VBox.setVgrow(miTabla, Priority.ALWAYS);

        cajaVertical.getChildren().add(miTabla);
        getChildren().add(cajaVertical);
    }

    private void losIconosAdmin() {
        int anchoIcono = 40;
        int sizeIcono = 16;

        Button btnEliminar = new Button();
        btnEliminar.setPrefWidth(anchoIcono);
        btnEliminar.setCursor(Cursor.HAND);
        btnEliminar.setGraphic(Icono.obtenerIcono(Configuracion.ICONO_BORRAR, sizeIcono));
        btnEliminar.setOnAction((e) -> {
            if (miTabla.getSelectionModel().getSelectedItem() == null) {
                Mensaje.mostrar(Alert.AlertType.WARNING, miEscenario,
                        "Atención", "Por favor selecciona una boleta");
            } else {
                BoletaDto obj = miTabla.getSelectionModel().getSelectedItem();
                String mensaje = "¿Estás seguro?\n\nCódigo: " + obj.getIdBoleta() +
                        "\nAsiento: " + obj.getNumeroAsientoBoleta() +
                        "\n\nEsta acción no se puede deshacer";

                Alert msg = new Alert(Alert.AlertType.CONFIRMATION);
                msg.setTitle("Confirmar Eliminación");
                msg.setHeaderText(null);
                msg.setContentText(mensaje);
                msg.initOwner(miEscenario);

                if (msg.showAndWait().get() == ButtonType.OK) {
                    int posi = miTabla.getSelectionModel().getSelectedIndex();
                    if (BoletaControladorEliminar.borrar(posi)) {
                        int canti = BoletaControladorListar.obtenerCantidadBoletas();
                        titulo.setText("ADMINISTRAR BOLETAS (" + canti + ")");

                        List<BoletaDto> datos = BoletaControladorListar.obtenerBoletas();
                        ObservableList<BoletaDto> datosTablo = FXCollections.observableArrayList(datos);

                        miTabla.setItems(datosTablo);
                        miTabla.refresh();
                        Mensaje.mostrar(Alert.AlertType.INFORMATION, miEscenario,
                                "Éxito", "Boleta eliminada correctamente");
                    } else {
                        Mensaje.mostrar(Alert.AlertType.ERROR, miEscenario,
                                "Error", "No se pudo eliminar la boleta");
                    }
                } else {
                    miTabla.getSelectionModel().clearSelection();
                }
            }
        });

        Button btnCancelar = new Button();
        btnCancelar.setPrefWidth(anchoIcono);
        btnCancelar.setCursor(Cursor.HAND);
        btnCancelar.setGraphic(Icono.obtenerIcono(Configuracion.ICONO_CANCELAR, sizeIcono));
        btnCancelar.setOnAction((e) -> {
            miTabla.getSelectionModel().clearSelection();
        });

        cajaBotones = new HBox(5);
        cajaBotones.setAlignment(Pos.CENTER);
        cajaBotones.getChildren().addAll(btnCancelar, btnEliminar);
        cajaVertical.getChildren().add(cajaBotones);
    }
}